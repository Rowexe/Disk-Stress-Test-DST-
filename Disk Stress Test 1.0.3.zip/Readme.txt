Thanks for downloading from me!

About:

Please email me if you want to contribute or have any suggestions/questions, my email: rowexe7@gmail.com

CHANGELOG:

1) New UI
2) New features
3) Made the test harder on the disk
4) Added a AI
5) Added auto-detection-safety (ads)